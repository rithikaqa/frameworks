package first.java;

public class MethodBasic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyFirstMethod();
		MyFirstMethod();
		
	}
	public static void MyFirstMethod(){
		System.out.println("Hello Santhosh");
	}
}
