package first.java;

public class Bank1_ABC extends Bank1 {
	int getInterestRate() {
		return 5;
	}

}
