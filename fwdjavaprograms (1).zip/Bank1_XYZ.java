package first.java;


	
	public class Bank1_XYZ extends Bank1 {
		
		
		int getInterestRate() {
			return 12;
		}

}
