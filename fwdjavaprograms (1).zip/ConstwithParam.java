package first.java;

class ConstwithParam {
	// A simple constructor.
	   int x;

	   // Following is the constructor
	   ConstwithParam() {
	      x = 10;
	   }
	}
	

