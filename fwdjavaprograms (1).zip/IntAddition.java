package first.java;

public class IntAddition {

public static void main(String[] args) {
		
		//define a method and call it.
			int a, b, c;
	       a = 11;
	       b = 6;
	       c = add(a, b);
	      System.out.println("addition = " + c );
}
	public static int add(int Number1,int Number2){
		int Sum;
		Sum = Number1 + Number2;
		return Sum;}
		  }

	
	
			

