package first.java;

public class Stirngs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String myString = "Hello World";
		int myStringLength = myString.length();
		String myStringincase = myString.toUpperCase();
		System.out.println(myString.indexOf('o'));
	}

}
