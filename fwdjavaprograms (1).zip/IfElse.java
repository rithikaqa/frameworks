package first.java;

public class IfElse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 20;
		if (x == 20) {
		System.out.println("equal to 20");
	}
	else {
		System.out.println("less than 20");
	}
	}

}
