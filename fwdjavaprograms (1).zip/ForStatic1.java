package first.java;

public class ForStatic1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ForStatic mark = new ForStatic();
		System.out.println(mark.getNoOfStudents());
		ForStatic tom = new ForStatic();
		System.out.println(tom.getNoOfStudents());
		
		System.out.println(ForStatic.getNoOfStudents());
		
		
	

	}

}
