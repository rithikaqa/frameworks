package first.java;

public class WhileDoWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 0;
		
		while (a <= -1)// a > 10, <=,>=
		{
			System.out.println(a);
			a++;
		}
			System.out.println("----------");
			
			
			int b = 0;
			do {
				System.out.println(b);
				b++;
			
		}
			while (b <= -1);

	
	}

}
