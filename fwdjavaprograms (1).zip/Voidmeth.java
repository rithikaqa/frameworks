package first.java;

public class Voidmeth {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		    methodforPoints(122.7);
			   }

			   public static void methodforPoints(double points) {
			      if (points >= 202.5) {
			         System.out.println("Rank:A1");
			      }else if (points >= 122.4) {
			         System.out.println("Rank:A2");
			      }else {
			         System.out.println("Rank:A3");
			      }
			   }
			}
	

