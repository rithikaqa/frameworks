package first.java;

public class Inher1Rect extends Inher1poly {
	//Rectangle class inheriting from polygon class
	//poly is derived class and rect is deriving class here
	
	/*if wee are inheriting from base class all protected members
	 & public members are accessible in derived class */
	
	public double area() {
		return (height* width);
		
	}

}
