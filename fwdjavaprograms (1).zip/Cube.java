package first.java;

public class Cube {
	int length;
	int bredth;
	int height;
	
	 public int getCubeVolume(){
		 return (length * bredth * height);
		 
	 }

	 Cube () {
		 length = 10;
		 bredth = 10;
		 height = 10;
	 }
		 Cube (int l,int b,int h) {
			 length = 20;
			 bredth = 20;
			 height = 20;
			 
	 
	 }
}