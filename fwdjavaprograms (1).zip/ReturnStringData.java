package first.java;

public class ReturnStringData {

	
		// TODO Auto-generated method stub
		
		    public final String value;
		    public final int index;

		    public ReturnStringData(String value, int index) {
		        this.value = value;
		        this.index = index;
		    }
		}
	


