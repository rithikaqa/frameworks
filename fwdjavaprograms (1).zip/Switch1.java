package first.java;

public class Switch1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int score = 90;
				switch (score) {
				case 90:
				System.out.println("very good");
				break;
				case 70:
			System.out.println("good");
			break;
			case 50:
				System.out.println("avg");
				break;
		default:{
			System.out.println("grades not defined");
		break;
		}
			

	}}

}
