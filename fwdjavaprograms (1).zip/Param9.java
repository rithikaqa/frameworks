package first.java;

public class Param9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int sum = Add(100,201,87);
		int result =sum * 2;
		System.out.println(result);
	}
	/*
	 * public static void sayHello(String Santhosh){
	 	System.out.println("Hello " + Santhosh);
	}
	 */
	
	public static int Add (int a,int b,int c)
	{
	//System.out.println(a+b+c);
	return (a+b+c);
	}
	
}
