package first.java;

public class Bank1_DEF extends Bank1 {
	
	
		int getInterestRate() {
			return 10;
		}
	

}
