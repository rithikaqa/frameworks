package first.java;

public class AndOr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int subject1 = 40;
		int subject2 = 60;
		// ANd && ,  OR ||
		//if ((subject1 > 40) && (subject2 < 70)){
		if 	((subject1 > 45) || (subject2 < 50)){
		System.out.println("condition is true");
	}
		else {
		System.out.println("condition is false");
		
	}}}