package first.java;

public class Bank1 {
	int getInterestRate() {
		return 0;
	}

}
