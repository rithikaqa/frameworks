package first.java;

public class Inher1Tri extends Inher1poly {


    public double area() {
	return (height* width)/2;

    }

}
